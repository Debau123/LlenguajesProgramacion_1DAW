# Projecto

## Industia_Videojuegos:
El Repositorio trata sobre hacer un xml  de la Industria Videojuegos. Dividida Videojuegos y Compañias

### Videojuegos:

- Videojuegos : Hemos echo un apartado de videojuegos donde dentro tenemos cada videojuego hecho.
  - Videojuego: Aqui en videojuego hemos puesto cada videojuego. Tienen como atributo el nombre de cada videojuego un codigo identificador, el presupuesto que tiene cada juego, y luego una idref de compañia que hace refencia a la compañia que desarrolo cada juego. Y videojuego tiene los sigientos elementos:
    1. Genero: Hace refencia al genero que pertenece cada juego.
    2. Plataformas: La platafor en la cual a salido el juego.
    3. Distribuidora: Empresa que se encarga de distribuir el videojuego.
    4. Caracteristicas: En este apartado hemos descrito las caracteristicas mas importantes o interesantes que nos han parecido.
    5. Motor de juego: El motor de desarollo que se utilizo para desarollar el videojuego.
    6. Foto : Aqui estara vacio pero en atributos esta el tipo de foto que es y la url de la foto .
    7. Premios: Aqui de forma opcional esta si el juego a ganado algun premio.

### Compañias:

- Compañias : En este apartado emos metido todas las compañias que han desarollado videojuegos.
  -  Compañia: Aqui emos puesto cada compañia desarolladora con un codigo identificador que es la idref que emos usado en videojuegos el nombre de caa compañia y otro atributo llamado videojuegos que es IDREFS para poner todos los videojuegos que han desarollado . Despues Compañia dentro tiene unos elementos que son los sigientes:
      1. Director: El director creativo o jefe de projecto de cada compañia.
      2. Año de Fundacion: El año en que se fundo cada estudio.
      3. Proximo juego: El proximo desarollo de la compañia.
      4. Pais origen: El pais donde esta la compañia.
      5. 6. Foto : Aqui estara vacio pero en atributos esta el tipo de foto que es y la url de la foto .